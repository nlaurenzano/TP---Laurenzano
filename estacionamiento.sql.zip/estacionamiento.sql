--
-- Base de datos: `estacionamiento`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estacionados`
--

CREATE TABLE `estacionados` (
  `id` int(11) NOT NULL,
  `patente` text COLLATE utf8_spanish_ci NOT NULL,
  `entrada` varchar(16) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `estacionados`
--

INSERT INTO `estacionados` (`id`, `patente`, `entrada`) VALUES
(18, 'poi890', '2016-11-06 22:31'),
(21, 'ppp123', '2016-11-06 23:11'),
(22, 'www112', '2016-11-07 02:12'),
(23, 'aaa111', '2016-11-07 03:44'),
(24, 'tre333', '2016-11-07 06:02'),
(25, 'ttt555', '2016-11-07 07:26'),
(26, 'bbb222', '2016-11-07 07:26'),
(27, 'asd321', '2016-11-07 17:13'),
(28, 'asd322', '2016-11-07 17:13'),
(29, 'sss111', '2016-11-07 17:14'),
(30, 'qqa223', '2016-11-07 17:15'),
(31, 'aaa321', '2016-11-07 17:23'),
(32, 'cxz234', '2016-11-07 17:23'),
(33, 'rrt555', '2016-11-07 17:23'),
(34, 'tty234', '2016-11-07 17:24'),
(35, 'jkl987', '2016-11-07 17:50'),
(36, 'bab678', '2016-11-08 00:41'),
(37, 'yui876', '2016-11-08 00:52'),
(38, 'asd222', '2016-11-08 00:54');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tickets`
--

CREATE TABLE `tickets` (
  `id` int(11) NOT NULL,
  `patente` text COLLATE utf8_spanish_ci NOT NULL,
  `entrada` varchar(16) COLLATE utf8_spanish_ci NOT NULL,
  `salida` varchar(16) COLLATE utf8_spanish_ci NOT NULL,
  `importe` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `tickets`
--

INSERT INTO `tickets` (`id`, `patente`, `entrada`, `salida`, `importe`) VALUES
(1, 'eee555', '2016-11-06 20:10', '2016-11-06 22:45', '83.94'),
(2, 'lmr798', '2016-11-06 20:33', '2016-11-06 22:53', '75.79'),
(3, 'hhh777', '2016-11-06 21:05', '2016-11-06 22:54', '59.20'),
(4, 'ggg777', '2016-11-06 20:32', '2016-11-06 22:55', '77.44'),
(5, 'lmr798', '2016-11-06 22:55', '2016-11-06 22:55', '0.50'),
(6, 'bla212', '2016-11-06 22:31', '2016-11-06 23:03', '17.67'),
(7, 'sss', '2016-11-08 00:57', '2016-11-08 00:58', '0.79');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `estacionados`
--
ALTER TABLE `estacionados`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `tickets`
--
ALTER TABLE `tickets`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `estacionados`
--
ALTER TABLE `estacionados`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;
--
-- AUTO_INCREMENT de la tabla `tickets`
--
ALTER TABLE `tickets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
